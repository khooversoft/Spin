﻿namespace Toolbox.Actor
{
    public interface IActor
    {
    }
}
