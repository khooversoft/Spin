﻿namespace Toolbox.Graph
{
    public interface IGraphCommon
    {
    }
}