﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Toolbox.Application
{
    public static class Constants
    {
        public const string ApiKeyName = "x-api-key";
        public const string BypassCacheName = "x-bypass-cache";
    }
}
