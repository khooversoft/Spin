﻿namespace Toolbox.Model
{
    public class PingResponse
    {
        public string? Message { get; set; }
        public string? Status { get; set; }
        public string? Version { get; set; }
    }
}