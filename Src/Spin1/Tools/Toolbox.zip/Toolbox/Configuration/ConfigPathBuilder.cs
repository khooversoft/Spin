﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Toolbox.Configuration
//{
//    public class ConfigPathBuilder
//    {
//        public string? Protocol { get; set; }

//        public string? Namespace { get; set; }

//        public string? Environment { get; set; }

//        public string? ConfigPath { get; set; }
//    }
//}
